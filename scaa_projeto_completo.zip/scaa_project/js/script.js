/**
 * SCAA - Sistema de Controle de Atividades Acadêmicas
 * Lógica de Front-end (JavaScript)
 */

// Estado da aplicação (Simulando banco de dados em memória)
let atividades = [
    {
        id: 1,
        titulo: 'Participação em palestra sobre inovação tecnológica',
        tipo: 'Palestra',
        data: '2026-03-12',
        cargaHoraria: 4,
        descricao: 'Palestra muito interessante sobre o futuro da tecnologia.',
        status: 'APROVADA'
    },
    {
        id: 2,
        titulo: 'Minicurso de JavaScript moderno',
        tipo: 'Minicurso',
        data: '2026-04-18',
        cargaHoraria: 8,
        descricao: 'Aprendizado sobre ES6+, Promises e Async/Await.',
        status: 'RECUSADA'
    }
];

// Elementos do DOM
const formAtividade = document.getElementById('form-atividade');
const listaAtividades = document.getElementById('lista-atividades');
const totalHorasEl = document.getElementById('total-horas');
const totalAtividadesEl = document.getElementById('total-atividades');
const filtroStatus = document.getElementById('filtro-status');
const emptyState = document.getElementById('empty-state');
const tabelaAtividades = document.getElementById('tabela-atividades');

// Inicialização
document.addEventListener('DOMContentLoaded', () => {
    renderizarAtividades();
    atualizarEstatisticas();
});

// Event Listeners
formAtividade.addEventListener('submit', cadastrarAtividade);
filtroStatus.addEventListener('change', renderizarAtividades);

/**
 * Função para cadastrar uma nova atividade
 */
function cadastrarAtividade(e) {
    e.preventDefault(); // Impede o recarregamento da página

    // Captura os valores do formulário
    const titulo = document.getElementById('titulo').value.trim();
    const tipo = document.getElementById('tipo').value;
    const data = document.getElementById('data').value;
    const cargaHoraria = parseFloat(document.getElementById('carga-horaria').value);
    const descricao = document.getElementById('descricao').value.trim();

    // Validação básica
    if (!titulo || !tipo || !data || isNaN(cargaHoraria) || !descricao) {
        alert('Por favor, preencha todos os campos obrigatórios.');
        return;
    }

    // Cria o objeto da nova atividade
    const novaAtividade = {
        id: Date.now(), // Gera um ID único baseado no timestamp
        titulo: titulo,
        tipo: tipo,
        data: data,
        cargaHoraria: cargaHoraria,
        descricao: descricao,
        status: 'PENDENTE' // Toda nova atividade entra como pendente
    };

    // Adiciona ao array (memória)
    atividades.push(novaAtividade);

    // Atualiza a interface
    renderizarAtividades();
    atualizarEstatisticas();

    // Limpa o formulário
    formAtividade.reset();
    
    // Feedback visual
    alert('Atividade cadastrada com sucesso! Ela foi enviada para validação do coordenador.');
}

/**
 * Função para remover uma atividade
 */
function removerAtividade(id) {
    if (confirm('Tem certeza que deseja remover esta atividade?')) {
        atividades = atividades.filter(atividade => atividade.id !== id);
        renderizarAtividades();
        atualizarEstatisticas();
    }
}

/**
 * Função para formatar a data (YYYY-MM-DD para DD/MM/YYYY)
 */
function formatarData(dataString) {
    const partes = dataString.split('-');
    if (partes.length === 3) {
        return `${partes[2]}/${partes[1]}/${partes[0]}`;
    }
    return dataString;
}

/**
 * Função para renderizar a lista de atividades na tabela
 */
function renderizarAtividades() {
    // Limpa a lista atual
    listaAtividades.innerHTML = '';
    
    const statusFiltro = filtroStatus.value;
    
    // Filtra as atividades se necessário
    const atividadesFiltradas = statusFiltro === 'TODOS' 
        ? atividades 
        : atividades.filter(a => a.status === statusFiltro);

    // Verifica se há atividades para mostrar
    if (atividadesFiltradas.length === 0) {
        tabelaAtividades.classList.add('hidden');
        emptyState.classList.remove('hidden');
        return;
    }

    tabelaAtividades.classList.remove('hidden');
    emptyState.classList.add('hidden');

    // Ordena por data (mais recente primeiro)
    atividadesFiltradas.sort((a, b) => new Date(b.data) - new Date(a.data));

    // Cria as linhas da tabela
    atividadesFiltradas.forEach(atividade => {
        const tr = document.createElement('tr');
        
        // Define a classe CSS baseada no status
        const statusClass = `status-${atividade.status.toLowerCase()}`;
        
        tr.innerHTML = `
            <td>${formatarData(atividade.data)}</td>
            <td>
                <span class="atividade-titulo">${atividade.titulo}</span>
                <span class="atividade-tipo">${atividade.tipo}</span>
            </td>
            <td>${atividade.cargaHoraria}h</td>
            <td><span class="status-badge ${statusClass}">${atividade.status}</span></td>
            <td>
                <button class="btn-action btn-remover" onclick="removerAtividade(${atividade.id})">Remover</button>
            </td>
        `;
        
        listaAtividades.appendChild(tr);
    });
}

/**
 * Função para atualizar os cards de estatísticas
 */
function atualizarEstatisticas() {
    // Total de atividades cadastradas
    totalAtividadesEl.textContent = atividades.length;
    
    // Total de horas (apenas atividades APROVADAS)
    const totalHoras = atividades
        .filter(a => a.status === 'APROVADA')
        .reduce((total, a) => total + a.cargaHoraria, 0);
        
    totalHorasEl.textContent = `${totalHoras}h`;
}
