-- =================================================================================
-- SISTEMA DE CONTROLE DE ATIVIDADES ACADÊMICAS (SCAA)
-- Script de Criação e População do Banco de Dados
-- SGBD: MySQL
-- =================================================================================

-- 1. CRIAÇÃO DO BANCO DE DADOS
CREATE DATABASE IF NOT EXISTS scaa_db
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

USE scaa_db;

-- 2. CRIAÇÃO DAS TABELAS (Modelo Relacional 2FN/3FN)

-- Tabela de Estudantes
CREATE TABLE IF NOT EXISTS estudante (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    curso VARCHAR(100) NOT NULL,
    data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de Coordenadores
CREATE TABLE IF NOT EXISTS coordenador (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    departamento VARCHAR(100) NOT NULL,
    data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de Tipos de Atividade
CREATE TABLE IF NOT EXISTS tipo_atividade (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(50) NOT NULL UNIQUE,
    descricao VARCHAR(255)
);

-- Tabela de Atividades
CREATE TABLE IF NOT EXISTS atividade (
    id INT AUTO_INCREMENT PRIMARY KEY,
    estudante_id INT NOT NULL,
    tipo_id INT NOT NULL,
    data_realizacao DATE NOT NULL,
    descricao TEXT NOT NULL,
    carga_horaria DECIMAL(5,2) NOT NULL,
    status ENUM('PENDENTE', 'APROVADA', 'RECUSADA') DEFAULT 'PENDENTE',
    data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (estudante_id) REFERENCES estudante(id) ON DELETE CASCADE,
    FOREIGN KEY (tipo_id) REFERENCES tipo_atividade(id) ON DELETE RESTRICT
);

-- Tabela de Validações (Histórico de aprovações/recusas)
CREATE TABLE IF NOT EXISTS validacao (
    id INT AUTO_INCREMENT PRIMARY KEY,
    atividade_id INT NOT NULL,
    coordenador_id INT NOT NULL,
    status_anterior ENUM('PENDENTE', 'APROVADA', 'RECUSADA') NOT NULL,
    status_novo ENUM('PENDENTE', 'APROVADA', 'RECUSADA') NOT NULL,
    observacoes TEXT,
    data_validacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (atividade_id) REFERENCES atividade(id) ON DELETE CASCADE,
    FOREIGN KEY (coordenador_id) REFERENCES coordenador(id) ON DELETE RESTRICT
);

-- 3. INSERÇÃO DE DADOS DE EXEMPLO

-- Inserindo Estudantes
INSERT INTO estudante (nome, email, curso) VALUES
('Débora Ester Silva', 'deboraester@email.com', 'Desenvolvimento Web'),
('Thiago Henrique Souza', 'thiago.souza@email.com', 'Sistemas de Informação'),
('Mariana Oliveira Costa', 'mariana.costa@email.com', 'Análise e Desenvolvimento de Sistemas');

-- Inserindo Coordenadores
INSERT INTO coordenador (nome, email, departamento) VALUES
('Prof. Carlos Mendes', 'carlos.mendes@email.com', 'Tecnologia da Informação'),
('Profa. Ana Paula', 'ana.paula@email.com', 'Ciências Exatas');

-- Inserindo Tipos de Atividade
INSERT INTO tipo_atividade (nome, descricao) VALUES
('Palestra', 'Participação em palestras acadêmicas ou profissionais'),
('Workshop', 'Participação em oficinas práticas'),
('Projeto de Extensão', 'Envolvimento em projetos sociais ou comunitários'),
('Minicurso', 'Cursos de curta duração'),
('Iniciação Científica', 'Participação em projetos de pesquisa acadêmica');

-- Inserindo Atividades
INSERT INTO atividade (estudante_id, tipo_id, data_realizacao, descricao, carga_horaria, status) VALUES
(1, 1, '2026-03-12', 'Participação em palestra sobre inovação tecnológica', 4.00, 'APROVADA'),
(2, 2, '2026-03-20', 'Workshop de desenvolvimento web responsivo', 6.00, 'PENDENTE'),
(3, 3, '2026-04-05', 'Participação em projeto social universitário', 12.00, 'APROVADA'),
(1, 4, '2026-04-18', 'Minicurso de JavaScript moderno', 8.00, 'RECUSADA'),
(2, 5, '2026-05-02', 'Pesquisa sobre banco de dados relacionais', 10.00, 'APROVADA');

-- Inserindo Validações (Simulando o histórico das atividades já avaliadas)
INSERT INTO validacao (atividade_id, coordenador_id, status_anterior, status_novo, observacoes) VALUES
(1, 1, 'PENDENTE', 'APROVADA', 'Certificado validado com sucesso.'),
(3, 2, 'PENDENTE', 'APROVADA', 'Excelente participação no projeto.'),
(4, 1, 'PENDENTE', 'RECUSADA', 'Certificado ilegível. Favor reenviar.'),
(5, 2, 'PENDENTE', 'APROVADA', 'Relatório de pesquisa aprovado.');

-- 4. CONSULTAS SQL SOLICITADAS NO PROJETO

-- Consulta 1: Listar todas as atividades com nome do estudante, tipo de atividade, data e status
/*
SELECT 
    e.nome AS Nome_Estudante,
    ta.nome AS Tipo_Atividade,
    DATE_FORMAT(a.data_realizacao, '%d/%m/%Y') AS Data_Realizacao,
    a.status AS Status_Validacao
FROM 
    atividade a
JOIN 
    estudante e ON a.estudante_id = e.id
JOIN 
    tipo_atividade ta ON a.tipo_id = ta.id
ORDER BY 
    a.data_realizacao DESC;
*/

-- Consulta 2: Calcular o total de horas acumuladas por estudante (apenas atividades APROVADAS)
/*
SELECT 
    e.nome AS Nome_Estudante,
    e.curso AS Curso,
    SUM(a.carga_horaria) AS Total_Horas_Aprovadas
FROM 
    estudante e
LEFT JOIN 
    atividade a ON e.id = a.estudante_id AND a.status = 'APROVADA'
GROUP BY 
    e.id, e.nome, e.curso
ORDER BY 
    Total_Horas_Aprovadas DESC;
*/

-- Consulta 3: Listar atividades pendentes de validação
/*
SELECT 
    a.id AS ID_Atividade,
    e.nome AS Nome_Estudante,
    ta.nome AS Tipo_Atividade,
    a.descricao AS Descricao,
    a.carga_horaria AS Horas,
    DATE_FORMAT(a.data_realizacao, '%d/%m/%Y') AS Data
FROM 
    atividade a
JOIN 
    estudante e ON a.estudante_id = e.id
JOIN 
    tipo_atividade ta ON a.tipo_id = ta.id
WHERE 
    a.status = 'PENDENTE'
ORDER BY 
    a.data_realizacao ASC;
*/
